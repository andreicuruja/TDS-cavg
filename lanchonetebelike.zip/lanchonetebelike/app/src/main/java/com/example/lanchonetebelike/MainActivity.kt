package com.example.lanchonetebelike

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.lanchonetebelike.R

class MainActivity : AppCompatActivity() {

    private lateinit var hamb: CheckBox
    private lateinit var batata: CheckBox
    private lateinit var refri: CheckBox
    private lateinit var sobr: CheckBox

    private lateinit var qtdHamb: EditText
    private lateinit var qtdBatata: EditText
    private lateinit var qtdRefri: EditText
    private lateinit var qtdSobr: EditText

    private lateinit var btnCalcular: Button
    private lateinit var labelTotal: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        hamb = findViewById(R.id.hamb)
        batata = findViewById(R.id.batata)
        refri = findViewById(R.id.refri)
        sobr = findViewById(R.id.sobr)

        qtdHamb = findViewById(R.id.qtdHamb)
        qtdBatata = findViewById(R.id.qtdBatata)
        qtdRefri = findViewById(R.id.qtdRefri)
        qtdSobr = findViewById(R.id.qtdSobr)

        btnCalcular = findViewById(R.id.btnCalcular)
        labelTotal = findViewById(R.id.labelTotal)

        btnCalcular.setOnClickListener {
            var soma = 0.0

            if (hamb.isChecked) {
                val quantidade = qtdHamb.text.toString().toIntOrNull() ?: 0
                soma += 12.00 * quantidade
            }

            if (batata.isChecked) {
                val quantidade = qtdBatata.text.toString().toIntOrNull() ?: 0
                soma += 8.00 * quantidade
            }

            if (refri.isChecked) {
                val quantidade = qtdRefri.text.toString().toIntOrNull() ?: 0
                soma += 6.00 * quantidade
            }

            if (sobr.isChecked) {
                val quantidade = qtdSobr.text.toString().toIntOrNull() ?: 0
                soma += 10.00 * quantidade
            }

            labelTotal.text = "Total: R$ %.2f".format(soma)
        }
    }
}