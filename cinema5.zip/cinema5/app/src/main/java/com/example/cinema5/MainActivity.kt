package com.example.cinema5
/**pesquisei no google pra aprender como fazer essas listas**/
import android.os.Bundle
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var labFilmes: TextView
    private lateinit var Filmes: Spinner
    private lateinit var Indicar: Button
    private lateinit var resultado: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        labFilmes = findViewById(R.id.labFilmes)
        Filmes = findViewById(R.id.Filmes)
        Indicar = findViewById(R.id.Indicar)
        resultado = findViewById(R.id.resultado)

        Indicar.setOnClickListener {
            val categoriaSelecionada = Filmes.selectedItem.toString()

            exibirTop5Filmes(categoriaSelecionada)
        }
    }

    /**
     * Função que define a lista de filmes para cada categoria e exibe na tela.
     */
    private fun exibirTop5Filmes(categoria: String) {
        val listaDeFilmes = when (categoria) {
            "Comédia" -> listOf(
                "1. Trovão Tropical",
                "2. Super-Herói o Filme",
                "3. Todo Mundo em Pânico",
                "4. Vizinhança do Barulho",
                "5. Inatividade Paranormal"
            )
            "Terror" -> listOf(
                "1. Corra!",
                "2. Invocação do Mal",
                "3. Hereditário",
                "4. Um Lugar Silencioso",
                "5. O Exorcista"
            )
            "Suspense" -> listOf(
                "1. O Silêncio dos Inocentes",
                "2. Fragmentado",
                "3. Seven: Os Sete Crimes Capitais",
                "4. A Origem",
                "5. Ilha do Medo"
            )
            "Ação" -> listOf(
                "1. Homem-Aranha 2",
                "2. Velozes e Furiosos Desafio em Tóquio",
                "3. Tropa de Elite",
                "4. John Wick",
                "5. Gran Turismo: De Jogador a Corredor"
            )
            else -> listOf("Categoria não encontrada.")
        }
        val filmesFormatados = listaDeFilmes.joinToString(separator = "\n")

        val textoFinal = "Top 5 $categoria:\n\n$filmesFormatados"

        resultado.text = textoFinal
    }
}