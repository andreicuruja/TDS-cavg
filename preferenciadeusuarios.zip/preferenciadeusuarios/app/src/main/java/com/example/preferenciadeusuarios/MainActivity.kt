package com.example.preferenciadeusuarios

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    // Declaração dos componentes da UI
    private lateinit var reais: EditText
    private lateinit var tipomoeda: Spinner
    private lateinit var converter: Button
    private lateinit var resultado: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Inicialização dos componentes da UI
        reais = findViewById(R.id.reais)
        tipomoeda = findViewById(R.id.tipomoeda)
        converter = findViewById(R.id.converter)
        resultado = findViewById(R.id.resultado)

        // Configuração do listener de clique para o botão de conversão
        converter.setOnClickListener {
            // 1. Pega o valor do EditText e tenta converter para Double
            val valor = reais.text.toString().toDoubleOrNull()

            // 2. Valida se o valor digitado é um número válido
            if (valor == null) {
                resultado.text = "Digite um valor válido"
                return@setOnClickListener // Encerra a execução do listener
            }

            // 3. Faz a conversão baseada no item selecionado no Spinner
            val convertido = when (tipomoeda.selectedItem.toString().trim()) { // Usei .trim() para remover espaços
                "Dolar" -> valor / 5.05 // Cotação atualizada como exemplo
                "Euro" -> valor / 5.45  // Cotação atualizada como exemplo
                "Pesos" -> valor / 0.0055 // Cotação atualizada como exemplo
                else -> 0.0
            }

            // 4. Exibe o resultado formatado com duas casas decimais
            resultado.text = "Resultado: ${String.format("%.2f", convertido)}"
        }
    }
}